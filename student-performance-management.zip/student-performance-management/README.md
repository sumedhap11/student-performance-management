# Student Performance Management System

**Assignment 6 — Advanced JavaScript and Node.js Application Development (WPT)**

A command-line application built with Node.js and ES6+ features that manages student records, calculates academic performance (total, average, grade, pass/fail), and generates reports. Records are stored in a JSON file and are retrieved asynchronously in later runs.

## Features

- Add students with ID, name, and any number of `subject=marks` pairs.
- Store records as arrays and objects in `data/students.json`.
- Calculate total marks, average marks, grade, and pass/fail status.
- Search for a student by ID with subject-wise marks.
- Filter students by grade (`A+`, `A`, `B`, `C`, `D`, `F`).
- Sort students by average marks (highest first).
- Rank students by average marks — students with equal averages share the same rank.
- Generate a full formatted performance report.
- Reject duplicate student IDs and marks outside the 0–100 range.
- Handle missing JSON files (treated as an empty list on the first run) and malformed JSON (friendly error message).
- Save data through a temporary file and rename, so the data file is never half-written.

## Grading Scale and Pass/Fail Rule

- **Grade (based on average marks):** `A+` ≥ 90, `A` ≥ 80, `B` ≥ 70, `C` ≥ 60, `D` ≥ 50, `F` < 50.
- **Pass/Fail (based on subjects):** a student is `PASS` only when every subject is 35 or more, otherwise `FAIL`.

## Technology Stack

- **Runtime:** Node.js (v22)
- **Language:** JavaScript ES6+ with ES Modules
- **Data Storage:** JSON file
- **File Handling:** Node.js `fs/promises` with `async/await`
- **Code Quality:** ESLint 9 (flat config)

## Project Structure

```text
student-performance-management/
├── data/
│   └── students.json              # student records (JSON array)
├── outputs/
│   ├── sample-run.txt             # captured console output of the commands
│   ├── test-results.txt           # captured output of the test script
│   └── lint.txt                   # captured output of ESLint
├── src/
│   ├── main.js                    # CLI entry point (commands and report formatting)
│   ├── student.js                 # Student class (total, average, grade, status)
│   ├── studentService.js          # search, filter, sort, rank, JSON load/save
│   └── validation.js              # record and marks validation
├── test/
│   └── runTests.js                # test script for all required test cases
├── eslint.config.js
├── package.json
├── repl-experiments.txt           # REPL experiments with expressions and outputs
├── REPORT.md                      # project report (analysis, experiments, tests)
└── README.md
```

## Installation and Execution

1. Open a terminal in the `student-performance-management` directory.
2. Install the dependencies:

   ```bash
   npm install
   ```

3. Seed the demo records (9 students):

   ```bash
   npm run seed
   ```

4. Run any command:

   ```bash
   npm start -- list
   npm start -- search 101
   npm start -- filter A
   npm start -- sort
   npm start -- rank
   npm start -- report
   npm start -- add 110 Ananya mathematics=88 science=92 programming=85
   ```

   Or call Node directly:

   ```bash
   node src/main.js report
   ```

5. Run the tests and the linter:

   ```bash
   npm test
   npm run lint
   ```

## Data Storage

Student records are stored in `data/students.json` as a JSON array:

```json
[
  {
    "id": 101,
    "name": "Aarav",
    "marks": {
      "mathematics": 85,
      "science": 91,
      "programming": 96
    }
  }
]
```

Every record is validated before it is loaded or saved. If the file is missing, the application starts with an empty list; if the file contains malformed JSON, a clear error message is shown instead of a crash.

## Implementation Highlights

- **ES Modules** (`import`/`export`) split the program into `student`, `studentService`, `validation`, and `main` modules.
- **Student class** with a destructuring constructor calculates total, average, grade, and pass/fail status.
- **Arrow functions** are used for all calculations and array transformations (`reduce`, `filter`, `map`, `sort` comparators).
- **Template literals** format the performance report and every console message.
- **Spread syntax** copies arrays before sorting and builds new lists when a student is added; **rest syntax** collects the `subject=marks` pairs in the `add` command.
- **async/await** with `fs/promises` reads and writes the JSON file, with `try/catch` for missing files and malformed JSON.
- Data is written to a temporary file and then **renamed**, so an interrupted write cannot corrupt the records.

## Learning Outcomes

This project demonstrates practical knowledge of Node.js command-line applications, ES6+ features (classes, modules, destructuring, spread/rest, arrow functions, template literals), asynchronous file handling, JSON storage, validation, ranking logic, and error handling.

## Author

**Name:** Sumedha Patil
**Roll Number:** 34
**Course:** Web Programming Technologies (WPT)

---

*Developed as part of the Web Programming Technologies assignment.*
